/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

/**
 *
 * @author Phil
 */
public class Users {
    String userName, passWord;
    
    boolean ConnectToUserDB(String DBName){
        return true;
    }
    
    boolean AddUser(String usr, String PW){
        userName=usr;
        passWord=PW;
        return true;
    }
    
    String GetUser(){
        return userName;
    }
    boolean Login(String usr, String PW){
        if(userName==usr && passWord==PW) return true;
        else return false;
    }
}

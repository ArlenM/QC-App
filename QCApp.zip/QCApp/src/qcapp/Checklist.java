/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

/**
 *
 * @author Phil
 */
public class Checklist {
    String clientName, listType, questions, attachments;
    
    boolean attachPhoto(String name){
        return true;
    }
    
    boolean attachComment(String comment){
        return true;
    }
    
    boolean createList(String list){
        return true;
    }
    
    boolean updateList(String list){
        return true;
    }
    
    boolean saveList(String list){
        return true;
    }
    
    boolean loadList(String list){
        return true;
    }
}

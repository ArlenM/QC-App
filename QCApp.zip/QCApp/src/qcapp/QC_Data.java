/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

/**
 *
 * @author Phil
 */
public class QC_Data {
String QCData;    
// Database link and queries
    
    
    boolean ConnectToQCDB(String DBName){
        return true;
    }
    boolean AddData(String dta){
        QCData = dta;
        return true;
    }
    
    String GetData(){
        return QCData;
    }
}

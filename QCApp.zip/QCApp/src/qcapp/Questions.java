/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;
import java.util.ArrayList;

/**
 *
 * @author Phil
 */
public class Questions {
    String status, assocProdType;
    Integer score;
    
    String getList(int listNum){
        ArrayList<String> lst = new ArrayList();
        lst.add(0, "First object");
        lst.add(1, "Second object");
        return lst.get(listNum);
    }
    
    Boolean changeScore(int score){
        return true;
    }
    
    Boolean changeStatus(String status){
        return true;
    }
    
    Boolean changeProductAssoc(String product){
        return true;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Phil
 */
public class OrdersTest {
    
    public OrdersTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of flagForQC method, of class Orders.
     */
    @Test
    public void testFlagForQC() {
        Orders ord = new Orders();
        boolean flagged = ord.flagForQC(456);
        assertTrue(flagged);
    }

    /**
     * Test of completeOrder method, of class Orders.
     */
    @Test
    public void testCompleteOrder() {
       Orders ord = new Orders();
        boolean complete = ord.completeOrder(5676);
        assertTrue(complete);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Phil
 */
public class QuestionsTest {
    
    public QuestionsTest() {
    }
    Questions qst = new Questions();
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getList method, of class Questions.
     */
    @Test
    public void testGetList() {
        String tester;
        tester = qst.getList(0);
        assertEquals(tester, "First object");
    }

    /**
     * Test of changeScore method, of class Questions.
     */
    @Test
    public void testChangeScore() {
        assertTrue(qst.changeScore(7));
    }

    /**
     * Test of changeStatus method, of class Questions.
     */
    @Test
    public void testChangeStatus() {
        assertTrue(qst.changeStatus("Closed"));
    }

    /**
     * Test of changeProductAssoc method, of class Questions.
     */
    @Test
    public void testChangeProductAssoc() {
        assertTrue(qst.changeProductAssoc("Latest and Greatest"));
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Phil
 */
public class ChecklistTest {
    
    public ChecklistTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of attachPhoto method, of class Checklist.
     */
    @Test
    public void testAttachPhoto() {
        Checklist chkl = new Checklist();
        boolean photo = chkl.attachPhoto("My Photo");
        assertTrue(photo);        
    }

    /**
     * Test of attachComment method, of class Checklist.
     */
    @Test
    public void testAttachComment() {
        Checklist chkl = new Checklist();
        boolean comment = chkl.attachComment("Comment");
        assertTrue(comment); 
    }

    /**
     * Test of createList method, of class Checklist.
     */
    @Test
    public void testCreateList() {
      Checklist chkl = new Checklist();
        boolean listing = chkl.createList("List Name");
        assertTrue(listing);   
    }

    /**
     * Test of updateList method, of class Checklist.
     */
    @Test
    public void testUpdateList() {
        Checklist chkl = new Checklist();
        boolean listing = chkl.updateList("New List");
        assertTrue(listing);   
    }

    /**
     * Test of saveList method, of class Checklist.
     */
    @Test
    public void testSaveList() {
       Checklist chkl = new Checklist();
        boolean saved = chkl.updateList("Save List");
        assertTrue(saved);   
    }

    /**
     * Test of loadList method, of class Checklist.
     */
    @Test
    public void testLoadList() {
        Checklist chkl = new Checklist();
        boolean listing = chkl.loadList("New List");
        assertTrue(listing);   
    }
    
}

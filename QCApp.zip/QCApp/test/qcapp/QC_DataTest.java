/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Phil
 */
public class QC_DataTest {
    
    public QC_DataTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ConnectToQCDB method, of class QC_Data.
     */
    @Test
    public void testConnectToQCDB() {
        QC_Data qcData = new QC_Data();
        Boolean connected = qcData.ConnectToQCDB("MyQCData");
        assertTrue(connected);
    }

    /**
     * Test of AddData method, of class QC_Data.
     */
    @Test
    public void testAddData() {
        QC_Data qcData = new QC_Data();
        Boolean added = qcData.AddData("SomeData");
        assertTrue(added);
    }

    /**
     * Test of GetData method, of class QC_Data.
     */
    @Test
    public void testGetData() {
        QC_Data qcData = new QC_Data();
        Boolean added = qcData.AddData("SomeData");
        String myData = qcData.GetData();
        assertEquals(myData,"SomeData");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Phil
 */
public class UsersTest {
    
    public UsersTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ConnectToUserDB method, of class Users.
     */
    @Test
    public void testConnectToUserDB() {
        Users usrTest = new Users();
        Boolean connected = usrTest.ConnectToUserDB("Secret");
        assertTrue(connected);
    }

    /**
     * Test of AddUser method, of class Users.
     */
    @Test
    public void testAddUser() {
        Users usrTest = new Users();
        Boolean added = usrTest.AddUser("Bob", "Pass");
        assertTrue(added);
    }

    /**
     * Test of GetUser method, of class Users.
     */
    @Test
    public void testGetUser() {
        Users usrTest = new Users();
        Boolean added = usrTest.AddUser("Bob", "Pass");
        String uname = usrTest.GetUser();
        assertEquals(uname,"Bob");
    }
    @Test
    public void testLogin() {  // Test Success
        Users usrTest = new Users();
        Boolean added = usrTest.AddUser("Bob", "Pass");
        Boolean loggedIn = usrTest.Login("Bob", "Pass");
        assertTrue(loggedIn);
    }
    @Test
    public void testLogin2() {  // Test Fail
        Users usrTest = new Users();
        Boolean added = usrTest.AddUser("Bob", "Pass");
        Boolean loggedIn = usrTest.Login("Run", "Pass");
        assertFalse(loggedIn);
    }
}
